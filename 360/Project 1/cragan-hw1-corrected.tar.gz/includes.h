/*
 * Chris Ragan
 * Dr. Remy
 * CPSC 3600
 * Project 1: includes.h
 *
 * Stuck all of my includes in here so they don't make the rest of my code ugly
 */

#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>